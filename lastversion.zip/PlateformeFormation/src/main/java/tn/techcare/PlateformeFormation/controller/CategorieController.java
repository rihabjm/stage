package tn.techcare.PlateformeFormation.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import tn.techcare.PlateformeFormation.model.Categorie;
import tn.techcare.PlateformeFormation.service.CategorieService;



@CrossOrigin("*")
@RestController
@RequestMapping("/categorie")
public class CategorieController {

	@Autowired 
	private CategorieService categorieservice ;
	
	
	@GetMapping("/get")
	public List<Categorie>getAllPromotion()
	{
		return categorieservice.getAllCategorie();
	}
	
	
}
