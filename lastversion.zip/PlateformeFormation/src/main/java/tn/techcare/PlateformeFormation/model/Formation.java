package tn.techcare.PlateformeFormation.model;

import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonIgnore;

@Entity
@Table(name = "formation")
public class Formation {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int id_formation;
	private String intitule_formation ;
	private String langue ;
	private int nombreheure ;
	private float prix ;
	@JsonIgnore
    @ManyToOne(cascade = CascadeType.ALL)
    @JoinColumn(name = "id_categorie")
	private Categorie categorie ;
	
	@JsonIgnore
    @ManyToOne(cascade = CascadeType.ALL)
    @JoinColumn(name = "id_date")
	private  Date date ;
	
	@JsonIgnore
    @ManyToOne(cascade = CascadeType.ALL)
    @JoinColumn(name = "id_etat")
	private  EtatFormation etatFormation ;
	
	@JsonIgnore
    @ManyToOne(cascade = CascadeType.ALL)
    @JoinColumn(name = "id_promotion")
	private  Promotion promotion ;
	
	@JsonIgnore
    @ManyToOne(cascade = CascadeType.ALL)
    @JoinColumn(name = "id_type")
	private  TypeFormation typeformation ;
	
	@JsonIgnore
	@OneToMany(mappedBy = "formation", cascade = {
	        CascadeType.ALL
	    })
	private List<Seance> senaces ;

	public int getId_formation() {
		return id_formation;
	}

	public void setId_formation(int id_formation) {
		this.id_formation = id_formation;
	}

	public String getIntitule_formation() {
		return intitule_formation;
	}

	public void setIntitule_formation(String intitule_formation) {
		this.intitule_formation = intitule_formation;
	}

	public String getLangue() {
		return langue;
	}

	public void setLangue(String langue) {
		this.langue = langue;
	}

	public int getNombreheure() {
		return nombreheure;
	}

	public void setNombreheure(int nombreheure) {
		this.nombreheure = nombreheure;
	}

	public float getPrix() {
		return prix;
	}

	public void setPrix(float prix) {
		this.prix = prix;
	}

	public Categorie getCategorie() {
		return categorie;
	}

	public void setCategorie(Categorie categorie) {
		this.categorie = categorie;
	}

	public Date getDate() {
		return date;
	}

	public void setDate(Date date) {
		this.date = date;
	}

	public EtatFormation getEtatFormation() {
		return etatFormation;
	}

	public void setEtatFormation(EtatFormation etatFormation) {
		this.etatFormation = etatFormation;
	}

	public Promotion getPromotion() {
		return promotion;
	}

	public void setPromotion(Promotion promotion) {
		this.promotion = promotion;
	}

	public TypeFormation getTypeformation() {
		return typeformation;
	}

	public void setTypeformation(TypeFormation typeformation) {
		this.typeformation = typeformation;
	}

	public List<Seance> getSenaces() {
		return senaces;
	}

	public void setSenaces(List<Seance> senaces) {
		this.senaces = senaces;
	}
	
	
}
