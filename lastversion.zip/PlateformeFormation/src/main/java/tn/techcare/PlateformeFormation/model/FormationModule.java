package tn.techcare.PlateformeFormation.model;


import java.util.List;


import javax.persistence.Entity;
import javax.persistence.ManyToMany;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonIgnore;




@Entity
@Table(name = "formationModule")
public class FormationModule extends Formation{
	
private String 	session ;

@JsonIgnore
@ManyToMany(mappedBy="FormationModule")
private List<FormationMetiers> FormationMetiers ;

public String getSession() {
	return session;
}

public void setSession(String session) {
	this.session = session;
}

public List<FormationMetiers> getFormationMetiers() {
	return FormationMetiers;
}

public void setFormationMetiers(List<FormationMetiers> formationMetiers) {
	FormationMetiers = formationMetiers;
}

	
	

}
