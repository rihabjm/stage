package tn.techcare.PlateformeFormation.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import tn.techcare.PlateformeFormation.model.TypeFormation;

public interface TypeFormationRepository extends JpaRepository<TypeFormation,Integer> {

}
