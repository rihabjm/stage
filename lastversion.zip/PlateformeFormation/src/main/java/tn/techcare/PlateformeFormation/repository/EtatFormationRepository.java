package tn.techcare.PlateformeFormation.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import tn.techcare.PlateformeFormation.model.EtatFormation;

public interface EtatFormationRepository extends JpaRepository<EtatFormation,Integer> {

 public EtatFormation findEtatFormationByEtat(String etat);
}
