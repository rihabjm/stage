package tn.techcare.PlateformeFormation.Impservice;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import tn.techcare.PlateformeFormation.repository.EtatFormationRepository;
import tn.techcare.PlateformeFormation.model.EtatFormation;
import tn.techcare.PlateformeFormation.service.EtatFormationService;
@Service
@Transactional
public class EtatFormationImpService implements EtatFormationService {
    
	@Autowired
	private EtatFormationRepository EtatFormationRepository  ;
	
	
	@Override
	public List<EtatFormation> getAllEtat() {
	
		return EtatFormationRepository.findAll();
	}


	@Override
	public String getEtatById(int id) {
		// TODO Auto-generated method stub
		return null;
	}


	@Override
	public EtatFormation getEtatByEtat(String etat) {
		// TODO Auto-generated method stub
		return EtatFormationRepository.findEtatFormationByEtat(etat);
	}

}
