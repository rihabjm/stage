package tn.techcare.PlateformeFormation.Impservice;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import tn.techcare.PlateformeFormation.model.TypeFormation;
import tn.techcare.PlateformeFormation.repository.TypeFormationRepository;
import tn.techcare.PlateformeFormation.service.TypeFormationService;
@Service
@Transactional
public class TypeFormationImpService implements  TypeFormationService {
	
	@Autowired
	private TypeFormationRepository typeformationrepository ;
	@Override
	public List<TypeFormation> getAllType() {
		
		return typeformationrepository.findAll();
	}
	
	
}
