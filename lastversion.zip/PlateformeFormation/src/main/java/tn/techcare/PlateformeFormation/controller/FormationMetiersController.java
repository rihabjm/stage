package tn.techcare.PlateformeFormation.controller;

import java.util.List;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import tn.techcare.PlateformeFormation.model.FormationMetiers;
import tn.techcare.PlateformeFormation.model.MessageReponse;
import tn.techcare.PlateformeFormation.service.FormationMetiersService;


@CrossOrigin("*")
@RestController
@RequestMapping("/formationMetiers")
public class FormationMetiersController {
	@Autowired
	private  FormationMetiersService formationMetiersService ;
	
	@PostMapping("/add")
	public MessageReponse ajouterreunion (@RequestBody FormationMetiers formation) {
		return formationMetiersService.ajoutFormation(formation);
	}
	
	@GetMapping("/get")
	public List<FormationMetiers> getAllFormationMetiers()
	{    
		return formationMetiersService.getAllFormation();
	}
	
	
	@PutMapping("update")
	private MessageReponse updateformation (@RequestBody FormationMetiers  formation ) {
		return formationMetiersService.updateFormation(formation) ;
		
	}

	@DeleteMapping("{id}")
	private MessageReponse deletformation (@PathVariable("id") int id) {
		return formationMetiersService.supprimerFormation(id) ;
		
	}
	
}
