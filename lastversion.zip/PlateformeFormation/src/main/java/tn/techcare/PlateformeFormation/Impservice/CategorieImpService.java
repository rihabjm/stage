package tn.techcare.PlateformeFormation.Impservice;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import tn.techcare.PlateformeFormation.model.Categorie;
import tn.techcare.PlateformeFormation.repository.CategorieRepository;
import tn.techcare.PlateformeFormation.service.CategorieService;


@Service
@Transactional
public class CategorieImpService implements CategorieService {

	@Autowired
	private CategorieRepository categorieRepository  ;
	
	
	@Override
	public List<Categorie> getAllCategorie() {
		// TODO Auto-generated method stub
		return (List<Categorie>) categorieRepository.findAll() ;
	}
	

}
