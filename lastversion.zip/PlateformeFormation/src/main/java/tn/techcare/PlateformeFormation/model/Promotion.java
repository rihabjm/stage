package tn.techcare.PlateformeFormation.model;

import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonIgnore;

@Entity
@Table(name = "promotion")
public class Promotion {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int id_promotion;
   private String designation ;
   private float 	prixreduit ;
   private String details  ;
	@JsonIgnore
	@OneToMany(mappedBy = "promotion", cascade = {
	        CascadeType.ALL
	    })
	private List<Formation> formations ;
	
	 @JsonIgnore
	    @ManyToOne(cascade = CascadeType.ALL)
	    @JoinColumn(name = "id_date")
	    private Date  date ; 
	
   
public int getId_promotion() {
	return id_promotion;
}
public void setId_promotion(int id_promotion) {
	this.id_promotion = id_promotion;
}
public String getDesignation() {
	return designation;
}
public void setDesignation(String designation) {
	this.designation = designation;
}
public float getPrixreduit() {
	return prixreduit;
}
public void setPrixreduit(float prixreduit) {
	this.prixreduit = prixreduit;
}
public String getDetails() {
	return details;
}
public void setDetails(String details) {
	this.details = details;
}
public List<Formation> getFormations() {
	return formations;
}
public void setFormations(List<Formation> formations) {
	this.formations = formations;
}
	
   
}
