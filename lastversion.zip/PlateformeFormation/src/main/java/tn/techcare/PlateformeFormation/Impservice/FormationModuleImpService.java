package tn.techcare.PlateformeFormation.Impservice;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import tn.techcare.PlateformeFormation.model.FormationModule;
import tn.techcare.PlateformeFormation.model.MessageReponse;
import tn.techcare.PlateformeFormation.repository.FormationModuleRepository;
import tn.techcare.PlateformeFormation.service.FormationModuleService;
@Service
@Transactional
public class FormationModuleImpService implements FormationModuleService  {
	@Autowired
	private FormationModuleRepository formationmoduleRepository ;
	
	
	@Override
	public MessageReponse ajoutFormationModule(FormationModule formation) {
		
		
		formationmoduleRepository.save(formation);
		return new MessageReponse(true, formation.getId_formation()+ "formation est ajouter ") ;
	}


	@Override
	public List<FormationModule> getAllFormation() {
		return formationmoduleRepository.findAll();
	}

}
