package tn.techcare.PlateformeFormation.model;


import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonIgnore;



@Entity
@Table(name ="typeformation")
public class TypeFormation {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int id_type ;
	private String type ;
	@JsonIgnore
	@OneToMany(mappedBy = "typeformation", cascade = {
	        CascadeType.ALL
	    })
	private List<Formation> formations ;	

	
	public int getId_type() {
		return id_type;
	}
	public void setId_type(int id_type) {
		this.id_type = id_type;
	}
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}

	

}
