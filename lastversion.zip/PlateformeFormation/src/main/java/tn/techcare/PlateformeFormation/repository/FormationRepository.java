package tn.techcare.PlateformeFormation.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.repository.CrudRepository;

import tn.techcare.PlateformeFormation.model.Formation;



public interface FormationRepository extends CrudRepository<Formation, Integer> {

}
