package tn.techcare.PlateformeFormation.service;

import java.util.List;

import tn.techcare.PlateformeFormation.model.TypeFormation;

public interface TypeFormationService {
  
public List<TypeFormation>getAllType(); 
	
}
